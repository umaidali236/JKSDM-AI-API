# JKSDM-AI-API
Contains API code for AI-based Content Suggestions for JKYSE App (J&amp;K Skill Development Mission)
